package kr.carrotvision.hud;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Display-only gate. A radar reflection is NOT evidence of a vehicle class. */
final class VehicleFilter<T extends VehicleFilter.Candidate> {
  static final float MIN_PROBABILITY = .85f;
  static final int MIN_OBSERVATIONS = 3;
  static final long MIN_CONFIRM_MS = 100, STALE_MS = 350;
  private static final int MAX_TRACKS = 24;

  static class Candidate {
    float x, y, v, p;
    String source = "", type = "";
  }

  private static final class Track<C extends Candidate> {
    C car;
    long firstSeen;
    int observations;
    Track(C car, long firstSeen, int observations) {
      this.car = car; this.firstSeen = firstSeen; this.observations = observations;
    }
  }

  private List<Track<T>> tracks = new ArrayList<>();
  private final List<T> visible = new ArrayList<>();
  private long lastSourceTime = Long.MIN_VALUE, lastUpdate = -1;

  static boolean accepts(Candidate car) {
    if (car == null || !Float.isFinite(car.x) || !Float.isFinite(car.y) ||
        !Float.isFinite(car.p) || car.x < 1 || car.x > 150 ||
        car.p < MIN_PROBABILITY || car.p > 1) return false;
    // Legacy bridges give every radar return p=1 and sometimes type="car".
    // Neither is a classification result. The bridge may emit only its
    // conservative lane-shaped radar subset as "radarVehicle".
    if (!"vision".equals(car.source) && !"radarVehicle".equals(car.source)) return false;
    if ("vision".equals(car.source) && Math.abs(car.y) > 2.6f) return false;
    if ("radarVehicle".equals(car.source) && Math.abs(car.y) > 5.5f) return false;
    String type = car.type == null ? "" : car.type.trim().toLowerCase(Locale.ROOT);
    switch (type) {
      case "": // Current model lead packets have no semantic type field.
      case "car": case "vehicle": case "sedan": case "suv":
      case "van": case "pickup": case "truck": case "bus":
        return true;
      default:
        return false; // cone, tree, curb, barrier, pedestrian, unknown, etc.
    }
  }

  static float matchScore(Candidate a, Candidate b) {
    if (!accepts(a) || !accepts(b)) return Float.POSITIVE_INFINITY;
    float dx = Math.abs(a.x-b.x), dy = Math.abs(a.y-b.y);
    if (dx > Math.max(4f, .08f*b.x) || dy > .8f) return Float.POSITIVE_INFINITY;
    return dx + 4f*dy;
  }

  List<T> update(List<T> incoming, long sourceTime, long now) {
    if (lastUpdate >= 0 && (now < lastUpdate || now-lastUpdate > STALE_MS)) clear();
    // A redraw or a repeated/out-of-order source sample must not confirm a track.
    if (sourceTime <= lastSourceTime) return new ArrayList<>(visible);
    lastSourceTime = sourceTime;
    lastUpdate = now;
    List<Track<T>> next = new ArrayList<>();
    boolean[] used = new boolean[tracks.size()];
    visible.clear();
    for (T car : incoming) {
      if (!accepts(car)) continue;
      boolean duplicate = false;
      for (Track<T> added : next) {
        if (Math.abs(added.car.x-car.x) < 1f && Math.abs(added.car.y-car.y) < .5f) {
          duplicate = true; break;
        }
      }
      if (duplicate) continue;
      int best = -1;
      float score = Float.POSITIVE_INFINITY;
      for (int i = 0; i < tracks.size(); i++) {
        if (used[i]) continue;
        String previousSource = tracks.get(i).car.source;
        if (car.source == null ? previousSource != null
            : !car.source.equals(previousSource)) continue;
        float candidateScore = matchScore(tracks.get(i).car, car);
        if (candidateScore < score) { best = i; score = candidateScore; }
      }
      Track<T> track;
      if (best < 0) {
        track = new Track<>(car, now, 1);
      } else {
        used[best] = true;
        Track<T> previous = tracks.get(best);
        track = new Track<>(car, previous.firstSeen,
            Math.min(MIN_OBSERVATIONS, previous.observations+1));
      }
      next.add(track);
      if (track.observations >= MIN_OBSERVATIONS && now-track.firstSeen >= MIN_CONFIRM_MS)
        visible.add(car);
      if (next.size() >= MAX_TRACKS) break;
    }
    // No ghost/holdover vehicles when the current model no longer sees them.
    tracks = next;
    return new ArrayList<>(visible);
  }

  boolean isFresh(long now) {
    return lastUpdate >= 0 && now >= lastUpdate && now-lastUpdate <= STALE_MS;
  }

  private void clear() {
    tracks.clear(); visible.clear(); lastUpdate = -1; lastSourceTime = Long.MIN_VALUE;
  }
}
