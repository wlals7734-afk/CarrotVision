package kr.carrotvision.hud;

import java.util.*;

public final class VehicleFilterCheck {
  private static void check(boolean value, String message) {
    if (!value) throw new AssertionError(message);
  }

  private static VehicleFilter.Candidate candidate(String source, float x, float y, float p, String type) {
    VehicleFilter.Candidate c = new VehicleFilter.Candidate();
    c.source = source; c.x = x; c.y = y; c.p = p; c.type = type;
    return c;
  }

  public static void main(String[] args) {
    check(VehicleFilter.accepts(candidate("vision", 24, 0, .90f, "car")), "Vision car accepted");
    check(VehicleFilter.accepts(candidate("radarVehicle", 24, -3.5f, .90f, "car")), "Filtered side car accepted");
    check(!VehicleFilter.accepts(candidate("radarState", 24, 0, 1f, "car")), "Raw radar rejected");
    check(!VehicleFilter.accepts(candidate("vision", 24, 0, .84f, "car")), "Low confidence rejected");
    check(!VehicleFilter.accepts(candidate("vision", 24, 0, .95f, "tree")), "Non-vehicle type rejected");
    check(!VehicleFilter.accepts(candidate("radarVehicle", 24, 7f, .90f, "car")), "Off-road candidate rejected");

    VehicleFilter<VehicleFilter.Candidate> filter = new VehicleFilter<>();
    List<VehicleFilter.Candidate> one = Collections.singletonList(candidate("vision", 24, 0, .90f, "car"));
    check(filter.update(one, 10, 0).isEmpty(), "First sample must be hidden");
    check(filter.update(one, 20, 50).isEmpty(), "Second sample must be hidden");
    check(filter.update(one, 30, 100).size() == 1, "Third sample confirms vehicle");
    check(filter.update(Collections.emptyList(), 40, 150).isEmpty(), "Missing sample removes vehicle");
    System.out.println("Vehicle-only filtering checks passed");
  }
}
