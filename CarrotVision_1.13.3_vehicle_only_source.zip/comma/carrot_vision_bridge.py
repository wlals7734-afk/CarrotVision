#!/usr/bin/env python3
"""Read-only bridge; does not publish controls or change driving settings."""
import json
import math
import os
import socket
import sys
import time

root = os.environ.get("OPENPILOT_ROOT", "/data/openpilot")
sys.path.insert(0, root)
sys.path.insert(1, os.path.join(root, "openpilot"))
import cereal.messaging as messaging

def points(line):
    result = []
    for x, y in zip(line.x, line.y):
        x, y = float(x), float(y)
        if math.isfinite(x) and math.isfinite(y) and 0 <= x <= 150:
            result.append([x, y])
    return result[:33]

def fresh(sm, service, now):
    if service not in sm.recv_time:
        return False
    age = now - sm.recv_time[service]
    return sm.seen[service] and sm.valid[service] and 0 <= age < 0.7

def optional_bool(obj, field):
    # pycapnp raises AttributeError for fields absent from the installed schema.
    try:
        return bool(getattr(obj, field))
    except AttributeError:
        return None

def active_state(sm, now):
    # Prefer actual lateral activity when supplied by this fork.
    if fresh(sm, "controlsState", now):
        lateral = optional_bool(sm["controlsState"], "lateralActive")
        if lateral is not None:
            return lateral
    # Newer schemas moved overall engagement to selfdriveState.
    for service in ("selfdriveState", "controlsState"):
        if fresh(sm, service, now):
            enabled = optional_bool(sm[service], "enabled")
            if enabled is not None:
                return enabled
    return False

def optional_field(obj, name, default=None):
    try:
        return getattr(obj, name)
    except AttributeError:
        return default

def _lane_position_is_vehicle_like(name, y):
    # UI/model Y is positive to the right. A raw radar echo outside a lane
    # centreline is much more likely to be a tree, curb, cone or divider.
    if name in ("leadsLeft", "leadLeft"):
        return -5.5 <= y <= -1.8
    if name in ("leadsRight", "leadRight"):
        return 1.8 <= y <= 5.5
    return abs(y) <= 1.5


def radar_cars(state):
    # Radar has no semantic object class in this protocol. Keep only stable,
    # lane-shaped candidates; the Android side also requires 3 samples before
    # drawing them. This prevents raw trees, cones, curbs and dividers from
    # being rendered as car sprites.
    grouped = []
    for name in ("leadsLeft", "leadsRight", "leadsCenter"):
        group = optional_field(state, name, ()) or ()
        grouped.extend((name, track) for track in group)
    if not grouped:
        grouped = [(name, optional_field(state, name)) for name in
                   ("leadOne", "leadTwo", "leadLeft", "leadRight")]
    result, seen_ids = [], set()
    for name, track in grouped:
        if track is None or not optional_field(track, "status", False):
            continue
        try:
            x = float(track.dRel)
            # Radar Y is positive LEFT; model/UI Y is positive RIGHT.
            y = -float(track.yRel)
            if not (math.isfinite(x) and math.isfinite(y) and 2 <= x <= 120
                    and _lane_position_is_vehicle_like(name, y)):
                continue
            track_id = int(optional_field(track, "radarTrackId", -1))
        except (AttributeError, TypeError, ValueError, OverflowError):
            continue
        if track_id >= 0 and track_id in seen_ids:
            continue
        if track_id < 0 and any(abs(c["x"]-x) < .25 and abs(c["y"]-y) < .15 for c in result):
            continue
        # Named side lists are raw radar groupings and must have a stable ID.
        # The legacy leadOne/leadTwo fields are already semantic lead slots.
        if track_id < 0 and name not in ("leadOne", "leadTwo"):
            continue
        if track_id >= 0:
            seen_ids.add(track_id)
        result.append(dict(x=x, y=y, p=.9, source="radarVehicle",
                           type="car"))
    return result

def vision_car(lead):
    # A model lead is evidence, not a guaranteed semantic classification.
    # Do not invent a "car" label or turn radar validity into probability.
    try:
        probability = float(lead.prob)
        x, y = float(lead.x[0]), float(lead.y[0])
        if not (math.isfinite(x) and math.isfinite(y) and math.isfinite(probability)
                and 1 <= x <= 150 and abs(y) <= 2.6
                and .85 <= probability <= 1):
            return None
        return dict(x=x, y=y, p=probability, source="vision", type="car")
    except (AttributeError, TypeError, ValueError, IndexError, OverflowError):
        return None

def merge_cars(vision, radar):
    # Prefer the camera lead when it overlaps a radar candidate. Radar may
    # contribute lane-shaped adjacent candidates, but never creates a raw one.
    result = list(vision)
    for candidate in radar:
        if not any(abs(v["x"]-candidate["x"]) < max(3.0, .1*candidate["x"]) and
                   abs(v["y"]-candidate["y"]) < .75 for v in vision):
            result.append(candidate)
    return result

def model_sample_time(sm):
    # Repeated transmissions of one model sample must not count as detections.
    try:
        stamps = getattr(sm, "logMonoTime", None)
        stamp = stamps.get("modelV2", 0) if hasattr(stamps, "get") else 0
    except (AttributeError, TypeError, ValueError):
        stamp = 0
    return int(stamp) if stamp > 0 else int(sm.recv_time["modelV2"] * 1e9)

def traffic_state(sm, now):
    # Matches carrotpilot selfdrive/ui/mici/onroad/traffic_light.py.
    if fresh(sm, "longitudinalPlan", now):
        state = optional_field(sm["longitudinalPlan"], "trafficState", 0)
        if state in (1, 2):
            return int(state)
    return 0

def main():
    services = ["carState", "modelV2", "controlsState", "radarState", "longitudinalPlan"]
    try:
        from cereal.services import SERVICE_LIST
        if "selfdriveState" in SERVICE_LIST:
            services.append("selfdriveState")
    except ImportError:
        pass
    sm = messaging.SubMaster(services)
    sent = 0
    print("CarrotVision bridge v2.5 started; unclassified radar objects hidden", flush=True)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    target = (os.environ.get("CARROT_VISION_HOST", "255.255.255.255"),
              int(os.environ.get("CARROT_VISION_PORT", "8855")))
    while True:
        sm.update(50)
        now = time.monotonic()
        # Never keep sending cached values with a newly generated timestamp.
        if not (fresh(sm, "carState", now) and fresh(sm, "modelV2", now)):
            time.sleep(0.05)
            continue
        cs, model = sm["carState"], sm["modelV2"]
        cars = []
        # leadsV3 entries can be the same lead at different prediction horizons.
        # Display only the present-time primary vision lead, not three fake cars.
        if len(model.leadsV3):
            car = vision_car(model.leadsV3[0])
            if car is not None:
                cars.append(car)
        # No raw radar-only object is allowed to become a displayed vehicle.
        if fresh(sm, "radarState", now):
            cars = merge_cars(cars, radar_cars(sm["radarState"]))
        lanes = [dict(p=float(prob), pts=points(line))
                 for line, prob in zip(model.laneLines, model.laneLineProbs)]
        packet = dict(version=2, fresh=True, time=int(time.time()*1000),
                      modelTime=model_sample_time(sm),
                      trafficState=traffic_state(sm, now),
                      speed=float(cs.vEgo)*3.6, steering=float(cs.steeringAngleDeg),
                      enabled=active_state(sm, now),
                      brakeLights=optional_bool(cs, "brakeLights"),
                      leftBlinker=bool(cs.leftBlinker), rightBlinker=bool(cs.rightBlinker),
                      leftBlindspot=bool(getattr(cs,"leftBlindspot",False)),
                      rightBlindspot=bool(getattr(cs,"rightBlindspot",False)),
                      cars=cars, path=points(model.position), lanes=lanes)
        try:
            sock.sendto(json.dumps(packet, allow_nan=False, separators=(",",":")).encode(),target)
            sent += 1
            if sent == 1:
                print("Sending fresh data to %s:%s" % target, flush=True)
        except (OSError, ValueError) as error:
            print(error, flush=True)
        time.sleep(0.05)

if __name__ == "__main__":
    main()
